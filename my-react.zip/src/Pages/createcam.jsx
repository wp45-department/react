import React, { useState } from "react";
import "./Style.css";
import Container from "@mui/material/Container";
import cardimage from "../../src/funding.png";
import logo1 from "../../src/logoipsum-247.svg";
import logo2 from "../../src/logoipsum-248.svg";
import logo3 from "../../src/logoipsum-249.svg";
import Grid from "@mui/material/Grid";
import { Button, ButtonGroup } from "@mui/material";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";

function App() {
  return (
    <Container
      className="cust-container cust-main-sec-campaign"
      fixed
      sx={{
        height: "auto",
        width: "auto",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      
    </Container>
  );
}

export default App;
